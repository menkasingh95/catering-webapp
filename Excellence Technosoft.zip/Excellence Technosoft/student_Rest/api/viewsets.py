from rest_framework import viewsets
from . import models
from . import serializers

class CandidateViewset(viewsets.ModelViewSet):
    queryset = models.Candidate.objects.all()
    serializer_class = serializers.CandidateSerializer
    
    
