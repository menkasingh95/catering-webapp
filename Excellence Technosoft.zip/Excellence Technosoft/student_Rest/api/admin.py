from django.contrib import admin
from api.models import Candidate
from api.models import TestScore
# Register your models here.
# class CandidateAdmin(admin.ModelAdmin): 
#     list_display=['email'] 

admin.site.register(Candidate),
admin.site.register(TestScore),