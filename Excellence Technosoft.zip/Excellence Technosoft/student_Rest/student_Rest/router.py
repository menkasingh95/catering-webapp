from api.viewsets import CandidateViewset
from rest_framework import routers

router = routers.DefaultRouter()
router.register('candidate',CandidateViewset)