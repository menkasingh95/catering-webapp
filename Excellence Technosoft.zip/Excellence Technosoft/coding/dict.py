# Write a function in python which will return maximum i.e function should return dictionary like this
# { “3” : 70 }

# Creating a Dictionary
# def max_min():
    # Dict1 = {"1" : 'name1', "2" : 'name2', "3" : 'name3'} 
    # Dict2 = {"1" : 50, "2" : 60, "3" : 70}
    # max_key = max(Dict2, key = Dict2.get)
    # max_value = max(Dict2.values())
    # print("Max Key and Value is:", max_key, max_value)
    # print(max(zip(Dict2.keys(), Dict2.values())))
# max_min()


Dict1 = {"1" : 'name1', "2" : 'name2', "3" : 'name3'} 
Dict2 = {"1" : 50, "2" : 60, "3" : 70}
print(max(zip(Dict2.keys(), Dict2.values())))


# d = {"1" : 'name1', "2" : 'name2', "3" : 'name3'} 
# d2 = {"1" : 50, "2" : 60, "3" : 70}
# for (k,v), (k2,v2) in zip(d.items(), d2.items()):
#     print(k, v)
#     print(k2, v2)

   





