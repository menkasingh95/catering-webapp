# Use python lists and make an list of numbers.
# Write a function which returns sum of the list of numbers

# Creating a List of numbers
List = [10, 20, 14, 50]
total_sum = 0
for i in List:
     total_sum = total_sum + i
# print("List of numbers:", List)
print("Sum of all numbers in given list:", total_sum)

# creating a function
def sum(numbers):
    total = 0
    for x in numbers:
        total += x
    return total
print(sum((8, 2, 3, 0, 7)))

